export class UserModel{
    id?:string
    name?:string
    email?:string
    active?:string
}